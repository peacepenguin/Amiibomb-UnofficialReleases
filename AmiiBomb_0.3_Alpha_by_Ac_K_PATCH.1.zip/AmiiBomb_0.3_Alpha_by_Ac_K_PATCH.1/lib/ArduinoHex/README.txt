updated hex files using new MFRC522 library
