AmiiBomb 0.3 Alpha
AmiiBombuino 0.1 Alpha
by Ac_K
=============================================================

For more informations, bugs report, or questions go to the GitHub: https://github.com/AcK77/AmiiBomb-uino/

If you want to support me, help me to improve AmiiBomb, you can donate me to my Paypal adress at ackeedy@gmail.com